#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "map.c"

void handleCInstruction(char *line, FILE *out_file, map compMap, map destMap, map jumpMap) {
    //converts a c_instruction into binary

    char dest[5] = "", comp[5] = "", jump[5] = "";
    char *equalPos = strchr(line, '=');
    char *semicolonPos = strchr(line, ';');

    // Extracts comp and dest (if there is one)
    if (equalPos) {
        strncpy(dest, line, equalPos - line);
        dest[equalPos - line] = '\0';
        strcpy(comp, equalPos + 1);
    } else {
        strcpy(comp, line);
        strcpy(dest,"null" );
    }

    // Extracting the jump (after the ';' sign)
    if (semicolonPos) {
        *semicolonPos = '\0';
        strcpy(jump, semicolonPos + 1);
    } else {
        strcpy(jump, "null");
    }

    // Look up the binary values for comp, dest, and jump
    char *compBits = lookupKey(compMap, comp);
    char *destBits = lookupKey(destMap, dest);
    char *jumpBits = lookupKey(jumpMap, jump);

    //writes the binary conversion to output file
    fprintf(out_file, "111%s%s%s\n", compBits, destBits, jumpBits);
}


void convert_a_instruction(char *line, FILE *out_file) {
    //converts an a_instruction into binary

    //saves number after @
    int value = atoi(line + 1);

    //creates 16-bit binary string
    char binary[17];
    binary[16] = '\0';
    for (int i = 15; i >= 0; i--) {
        binary[i] = (value % 2) ? '1' : '0';
        value /= 2;
    }

    //writes the binary conversion to output file
    fprintf(out_file, "%s\n", binary);
}

void parse_instruction(char *line, FILE *out_file, map compMap, map destMap, map jumpMap){
    //parses through inputted line and outputs binary into out_file

    //gets ride of white space in the line
    for (int i=0; line[i]; i++) {
        if (isspace(line[i])) {
            line[i] = '\0';
            break;
        }
    }

    // Check for A-instruction
    if (line[0] == '@') {
        convert_a_instruction(line, out_file);
    }
    // Check for C-instruction
    else if (strchr(line, '=')) {
        handleCInstruction(line, out_file, compMap, destMap, jumpMap);
    }
}

int main(int argc, char *argv[]) {
    //Reads through .asm file and outputs .hack file (excluding label instructions)

    if ( argc < 2 ) {
		exit(0);
	}else {
        //initializing maps for comp, dest, and jump
        map compMap = createMap(28);
        compMap = initializeCompMap(compMap);

        map destMap = createMap(8);
        destMap = initializeDestMap(destMap);
        
        map jumpMap = createMap(8); 
        jumpMap = initializeJumpMap(jumpMap);

        //Reading submitted file
        char* infile = argv[1];
        FILE *file = fopen(infile, "r");

        //creating output .hack file
        char* outfile = (char*)malloc(strlen(infile)+2);
        strncpy(outfile, infile, strlen(infile) - 4);
        outfile[strlen(infile) - 4] = '\0';
        strcat(outfile, ".hack");
        FILE *out_file = fopen(outfile, "w");

        //Iterates throughe ach line and calls parse_instrucion method
        char line[256]; // Buffer to store a line
        while (fgets(line, sizeof(line), file) != NULL) {
            parse_instruction(line, out_file, compMap, destMap, jumpMap); // Print each line for now
        }

        //Close files after done reading and writing
        fclose(file);
        fclose(out_file);
    }
}